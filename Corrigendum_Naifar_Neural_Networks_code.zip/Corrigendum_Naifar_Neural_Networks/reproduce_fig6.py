"""Re-run the MNIST autoencoder experiment of Fig. 6 with the released code.

The training code below is the autoencoder script of TFGD.txt (lines 583-707 of commit 1a6d0b5),
copied unchanged except for:
  (i)   the MNIST loader (keras if installed; otherwise a local keras-format mnist.npz given with
        --npz, or scikit-learn's OpenML copy of MNIST, whose first 60000 rows are the training set);
  (ii)  a configuration switch (number of training images, hidden units, epochs), so that the
        descriptions of the experiment given in the article can be compared;
  (iii) np.random.seed(s) before each optimiser's weight initialisation, so that TFGD and Adam start
        from the same weights (the released script draws both initialisations unseeded).

Configurations
  a  released script: all 60000 training images, 784-128-784, 50 full-batch epochs
  b  as in the caption of Fig. 6: first 10000 images, 784-64-784, 50 epochs
  c  as in the second paragraph on Fig. 6: first 10000 images, 784-64-784, 20 epochs
  d  first 10000 images, 784-128-784, 50 epochs

Note: with the released update rule, S = grad + exp(-lambda) * S, "TFGD" here is heavy-ball
momentum with beta = exp(-0.5); alpha is stored but never read.

The output JSON records, besides every loss curve, the data source, the shape, dtype and SHA-256
of the training images used (uint8, 60000 x 784, C order), the software versions, the operating
system and the BLAS thread pools, so that a re-run can be compared with this one.

usage: python reproduce_fig6.py [--configs a,b,c,d] [--seeds 0,1,2] [--npz mnist.npz] [--out FILE.json]
Config (a) takes roughly 10-20 minutes per seed on a laptop CPU (full-batch, 60000 x 784);
configs (b)-(d) take about a minute per seed.
"""
import argparse
import hashlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone

import numpy as np

CONFIGS = {
    "a": dict(n_samples=60000, hidden_dim=128, epochs=50,
              desc="released script: all 60000 training images, 784-128-784, 50 epochs"),
    "b": dict(n_samples=10000, hidden_dim=64, epochs=50,
              desc="caption of Fig. 6: first 10000 images, 784-64-784, 50 epochs"),
    "c": dict(n_samples=10000, hidden_dim=64, epochs=20,
              desc="second paragraph on Fig. 6: first 10000 images, 784-64-784, 20 epochs"),
    "d": dict(n_samples=10000, hidden_dim=128, epochs=50,
              desc="first 10000 images, 784-128-784, 50 epochs"),
}


def load_mnist_train(npz_path=None):
    """Return (x_train as loaded, description of the source, versions of the loader packages)."""
    if npz_path:
        with np.load(npz_path, allow_pickle=False) as z:
            return z["x_train"], f"keras-format npz file {os.path.basename(npz_path)}", {}
    try:
        import tensorflow as tf
        from tensorflow.keras.datasets import mnist  # as in TFGD.txt
        (x_train, _), _ = mnist.load_data()
        return x_train, "tensorflow.keras.datasets.mnist.load_data()", {"tensorflow": tf.__version__}
    except ImportError:
        pass
    import sklearn
    from sklearn.datasets import fetch_openml  # OpenML 554 (mnist_784): rows 0-59999 = training set
    X = fetch_openml("mnist_784", version=1, as_frame=False, parser="liac-arff").data
    return X[:60000], "sklearn.datasets.fetch_openml('mnist_784', version=1), rows 0-59999", \
        {"scikit-learn": sklearn.__version__}


def environment(loader_versions):
    env = {"python": sys.version.split()[0], "numpy": np.__version__, **loader_versions,
           "platform": platform.platform(), "machine": platform.machine(),
           "processor": platform.processor(), "cpu_count": os.cpu_count(),
           "started_utc": datetime.now(timezone.utc).isoformat(timespec="seconds")}
    try:
        from threadpoolctl import threadpool_info
        env["blas_threadpools"] = [{k: p.get(k) for k in ("internal_api", "version", "num_threads")}
                                   for p in threadpool_info()]
    except ImportError:
        env["blas_threadpools"] = "threadpoolctl not installed"
    env["thread_env"] = {k: os.environ.get(k) for k in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")}
    return env


def run_config(x_all, C, seeds, epochs_override=None):
    # Data and hyperparameters as in the released script
    x_train = x_all[:C["n_samples"]]
    input_dim = x_train.shape[1]
    hidden_dim = C["hidden_dim"]
    epochs = C["epochs"] if epochs_override is None else epochs_override
    learning_rate = 0.01

    # ----- released code from here on (TFGD.txt, autoencoder script) -----
    def sigmoid(x):
        return 1 / (1 + np.exp(-x))

    def sigmoid_deriv(x):
        s = sigmoid(x)
        return s * (1 - s)

    def mse_loss(x_true, x_pred):
        return np.mean((x_true - x_pred) ** 2)

    class TFGDOptimizer:
        def __init__(self, alpha, lambd):
            self.alpha = alpha
            self.lambd = lambd
            self.S = None

        def update(self, params, grads):
            if self.S is None:
                self.S = np.zeros_like(params)
            self.S = grads + np.exp(-self.lambd) * self.S
            return params - learning_rate * self.S

    class AdamOptimizer:
        def __init__(self, lr=0.001, beta1=0.9, beta2=0.999, eps=1e-8):
            self.lr = lr
            self.beta1 = beta1
            self.beta2 = beta2
            self.eps = eps
            self.m = None
            self.v = None
            self.t = 0

        def update(self, params, grads):
            if self.m is None:
                self.m = np.zeros_like(grads)
                self.v = np.zeros_like(grads)
            self.t += 1
            self.m = self.beta1 * self.m + (1 - self.beta1) * grads
            self.v = self.beta2 * self.v + (1 - self.beta2) * (grads ** 2)
            m_hat = self.m / (1 - self.beta1 ** self.t)
            v_hat = self.v / (1 - self.beta2 ** self.t)
            return params - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)

    def train_autoencoder(optimizer_class, opt_kwargs):
        W1 = np.random.randn(input_dim, hidden_dim) * 0.01
        b1 = np.zeros(hidden_dim)
        W2 = np.random.randn(hidden_dim, input_dim) * 0.01
        b2 = np.zeros(input_dim)

        opt_W1 = optimizer_class(**opt_kwargs)
        opt_b1 = optimizer_class(**opt_kwargs)
        opt_W2 = optimizer_class(**opt_kwargs)
        opt_b2 = optimizer_class(**opt_kwargs)

        losses = []
        for epoch in range(1, epochs + 1):
            z1 = x_train.dot(W1) + b1
            h = sigmoid(z1)
            z2 = h.dot(W2) + b2
            x_rec = sigmoid(z2)

            loss = mse_loss(x_train, x_rec)
            losses.append(loss)  # recorded before the update, as released

            d_rec = (x_rec - x_train) * sigmoid_deriv(z2) / x_train.shape[0]
            dW2 = h.T.dot(d_rec)
            db2 = np.sum(d_rec, axis=0)

            dh = d_rec.dot(W2.T) * sigmoid_deriv(z1)
            dW1 = x_train.T.dot(dh)
            db1 = np.sum(dh, axis=0)

            W2 = opt_W2.update(W2, dW2)
            b2 = opt_b2.update(b2, db2)
            W1 = opt_W1.update(W1, dW1)
            b1 = opt_b1.update(b1, db1)

        return losses
    # ----- end of released code -----

    runs = []
    for s in seeds:
        np.random.seed(s)
        t0 = time.time()
        loss_tfgd = train_autoencoder(TFGDOptimizer, {'alpha': 0.6, 'lambd': 0.5})
        t1 = time.time()
        np.random.seed(s)
        loss_adam = train_autoencoder(AdamOptimizer, {'lr': 0.001})
        t2 = time.time()
        print(f"  seed {s}: final loss TFGD {loss_tfgd[-1]:.5f}, Adam {loss_adam[-1]:.5f} "
              f"({(t1 - t0) / epochs:.1f} and {(t2 - t1) / epochs:.1f} s per epoch)", flush=True)
        runs.append({"seed": s,
                     "tfgd": [float(v) for v in loss_tfgd],
                     "adam": [float(v) for v in loss_adam],
                     "sec_per_epoch": {"tfgd": round((t1 - t0) / epochs, 3), "adam": round((t2 - t1) / epochs, 3)}})
    T = np.array([r["tfgd"] for r in runs])
    A = np.array([r["adam"] for r in runs])
    return {"desc": C["desc"], "n_samples": int(x_train.shape[0]), "hidden_dim": hidden_dim, "epochs": epochs,
            "learning_rate_tfgd": learning_rate, "lambda": 0.5, "alpha_stored_but_unused": 0.6,
            "learning_rate_adam": 0.001, "seeds": list(seeds),
            "summary": {"initial_loss_mean": {"tfgd": float(T[:, 0].mean()), "adam": float(A[:, 0].mean())},
                        "loss_index19_mean": {"tfgd": float(T[:, min(19, epochs - 1)].mean()),
                                              "adam": float(A[:, min(19, epochs - 1)].mean())},
                        "final_loss_mean": {"tfgd": float(T[:, -1].mean()), "adam": float(A[:, -1].mean())},
                        "final_loss_range": {"tfgd": [float(T[:, -1].min()), float(T[:, -1].max())],
                                             "adam": [float(A[:, -1].min()), float(A[:, -1].max())]}},
            "runs": runs}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--configs", default="a,b,c,d", help="comma-separated subset of a,b,c,d")
    ap.add_argument("--seeds", default="0,1,2", help="comma-separated, e.g. 0,1,2")
    ap.add_argument("--npz", default=None, help="keras-format mnist.npz (optional)")
    ap.add_argument("--epochs", type=int, default=None, help="override the number of epochs (for a quick test)")
    ap.add_argument("--out", default="fig6_results.json", help="output JSON")
    args = ap.parse_args()
    configs = [c.strip() for c in args.configs.split(",")]
    for c in configs:
        if c not in CONFIGS:
            ap.error(f"unknown configuration {c!r}")
    seeds = [int(t) for t in args.seeds.split(",")]

    # Load MNIST data (loader replaced, preprocessing as released)
    x_raw, source, loader_versions = load_mnist_train(args.npz)
    raw_shape, raw_dtype = list(x_raw.shape), str(x_raw.dtype)
    x_u8 = np.ascontiguousarray(np.asarray(x_raw).reshape((x_raw.shape[0], -1)).astype(np.uint8))
    data_sha256 = hashlib.sha256(x_u8.tobytes()).hexdigest()
    x_all = x_raw.astype('float32') / 255.0
    x_all = x_all.reshape((x_all.shape[0], -1))  # flatten to (60000, 784)

    results = {
        "description": "Output of reproduce_fig6.py. Losses are recorded before each update, as in the "
                       "released script: index 0 is the initial loss, index 19 the loss after 19 updates.",
        "command": "python " + " ".join([os.path.basename(sys.argv[0])] + sys.argv[1:]),
        "data": {"source": source, "shape_as_loaded": raw_shape, "dtype_as_loaded": raw_dtype,
                 "sha256_uint8_60000x784_C_order": data_sha256,
                 "preprocessing": "astype(float32) / 255, reshape to (N, 784), first n_samples rows"},
        "environment": environment(loader_versions),
        "configs": {},
    }
    print(f"data: {source}; sha256 {data_sha256}", flush=True)
    for c in configs:
        print(f"config {c}: {CONFIGS[c]['desc']}", flush=True)
        results["configs"][c] = run_config(x_all, CONFIGS[c], seeds, args.epochs)
        with open(args.out, "w") as f:  # written after each configuration
            json.dump(results, f)
    results["environment"]["finished_utc"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with open(args.out, "w") as f:
        json.dump(results, f)
    print("wrote", args.out)


if __name__ == "__main__":
    main()
