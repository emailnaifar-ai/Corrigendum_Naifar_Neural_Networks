"""
Replacement results for the corrigendum to
O. Naifar, "Tempered fractional gradient descent: Theory, algorithms, and robust
learning applications", Neural Networks 193 (2026) 108005.

All TFGD numbers are produced with the update rule of the released implementation
(TFGD.txt, commit 1a6d0b5, lines 146-157):  S <- grad + exp(-lambda) * S ;  theta <- theta - eta * S.
Protocol (identical to the released script unless stated):
  * Breast Cancer Wisconsin, StandardScaler on all features, train_test_split(test_size=0.2,
    random_state=42)  -> 455 train / 114 test.
  * Logistic regression, full-batch gradients, N(0,1) initialisation of weights and bias.
  * NEW: 30 seeds (0..29); the seed fixes the initialisation, and every optimiser sees the same
    initialisation for a given seed (paired design).
  * Accuracy and final training loss after 100 epochs; convergence epoch = first epoch at which
    the released criterion (|Delta loss| < 1e-4 over the last 5 recorded losses) holds, within 200.

Writes LaTeX fragments to ./corrigendum/tables, the figure to ./corrigendum/figures and all
numbers to ./corrigendum_results.json.

Run:   python reproduce_corrigendum_results.py [--out DIR]
       (DIR receives tables/ and figures/; default ./corrigendum next to this script)
"""
import argparse
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from scipy import stats  # noqa: E402
from sklearn.datasets import load_breast_cancer, load_digits, make_classification  # noqa: E402
from sklearn.metrics import accuracy_score  # noqa: E402
from sklearn.model_selection import train_test_split  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
_ap = argparse.ArgumentParser()
_ap.add_argument("--out", default=os.path.join(HERE, "corrigendum"))
OUTDIR = os.path.abspath(_ap.parse_args().out)
TAB = os.path.join(OUTDIR, "tables")
FIG = os.path.join(OUTDIR, "figures")
os.makedirs(TAB, exist_ok=True)
os.makedirs(FIG, exist_ok=True)

SEEDS = list(range(30))
SEEDS_EXTRA = list(range(10))
EPOCHS = 100
MAX_EPOCHS = 200
CONV_THRESHOLD = 1e-4
CONV_PATIENCE = 5
STATE_BYTES = 31 * 8  # one float64 buffer for 30 weights + 1 bias


# ----------------------------------------------------------------------------- optimisers
class TFGDReleased:
    """Update rule of TFGD.txt (commit 1a6d0b5). alpha is stored but, as in the release, unused."""

    def __init__(self, alpha, lambd, lr=0.1):
        self.alpha, self.lambd, self.lr, self.S = alpha, lambd, lr, None

    def update(self, params, grads):
        if self.S is None:
            self.S = np.zeros_like(params)
        self.S = grads + np.exp(-self.lambd) * self.S
        return params - self.lr * self.S


class GD:
    def __init__(self, lr):
        self.lr = lr

    def update(self, params, grads):
        return params - self.lr * grads


class HeavyBall:
    def __init__(self, beta, lr):
        self.beta, self.lr, self.v = beta, lr, None

    def update(self, params, grads):
        if self.v is None:
            self.v = np.zeros_like(params)
        self.v = self.beta * self.v + grads
        return params - self.lr * self.v


class Adam:  # verbatim from TFGD.txt lines 503-522
    def __init__(self, lr=0.001, beta1=0.9, beta2=0.999, eps=1e-8):
        self.lr, self.beta1, self.beta2, self.eps = lr, beta1, beta2, eps
        self.m = self.v = None
        self.t = 0

    def update(self, params, grads):
        if self.m is None:
            self.m = np.zeros_like(grads)
            self.v = np.zeros_like(grads)
        self.t += 1
        self.m = self.beta1 * self.m + (1 - self.beta1) * grads
        self.v = self.beta2 * self.v + (1 - self.beta2) * (grads ** 2)
        m_hat = self.m / (1 - self.beta1 ** self.t)
        v_hat = self.v / (1 - self.beta2 ** self.t)
        return params - self.lr * m_hat / (np.sqrt(v_hat) + self.eps)


class RMSprop:  # verbatim from TFGD.txt lines 525-536
    def __init__(self, lr=0.001, decay=0.9, eps=1e-8):
        self.lr, self.decay, self.eps = lr, decay, eps
        self.cache = None

    def update(self, params, grads):
        if self.cache is None:
            self.cache = np.zeros_like(grads)
        self.cache = self.decay * self.cache + (1 - self.decay) * (grads ** 2)
        return params - self.lr * grads / (np.sqrt(self.cache) + self.eps)


# ----------------------------------------------------------------------------- model / training
def sigmoid(z):
    return 1 / (1 + np.exp(-z))


def ce(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + 1e-8) + (1 - y_true) * np.log(1 - y_pred + 1e-8))


def run(make_opt, Xtr, ytr, Xte, yte, seed, n_epochs, snapshot=EPOCHS):
    """Returns (recorded losses, test acc after `snapshot` epochs, train loss after `snapshot` epochs, params)."""
    np.random.seed(seed)
    w = np.random.randn(Xtr.shape[1])
    b = np.random.randn()
    ow, ob = make_opt(), make_opt()
    losses, acc_snap, loss_snap = [], None, None
    for ep in range(1, n_epochs + 1):
        p = sigmoid(Xtr @ w + b)
        losses.append(ce(ytr, p))
        err = p - ytr
        dw = (Xtr.T @ err) / len(ytr)
        db = np.mean(err)
        w = ow.update(w, dw)
        b = ob.update(b, db)
        if ep == snapshot:
            acc_snap = accuracy_score(yte, (sigmoid(Xte @ w + b) > 0.5).astype(int))
            loss_snap = ce(ytr, sigmoid(Xtr @ w + b))
    return np.array(losses), acc_snap, loss_snap, np.append(w, b)


def conv_epoch(losses):
    """Released criterion (TFGD.txt lines 190-195)."""
    for ep in range(CONV_PATIENCE + 1, len(losses) + 1):
        if np.all(np.abs(np.diff(losses[ep - CONV_PATIENCE:ep])) < CONV_THRESHOLD):
            return ep
    return None


def pm(a, d=2):
    a = np.asarray(a, dtype=float)
    return f"{a.mean():.{d}f} $\\pm$ {a.std(ddof=1):.{d}f}"


# ----------------------------------------------------------------------------- data
data = load_breast_cancer()
X = StandardScaler().fit_transform(data.data)
Xtr, Xte, ytr, yte = train_test_split(X, data.target, test_size=0.2, random_state=42)
assert len(yte) == 114

results = {"protocol": __doc__, "breast_cancer": {}, "sensitivity": {}, "extra": {}}

# ----------------------------------------------------------------------------- Table R1
beta05 = np.exp(-0.5)
eff = 0.1 / (1 - beta05)
METHODS = [
    ("tfgd", r"TFGD as implemented ($\alpha=0.6$, $\lambda=0.5$)", lambda: TFGDReleased(0.6, 0.5)),
    ("gd01", r"GD, $\eta=0.1$ (``SGD'' in the article)", lambda: GD(0.1)),
    ("gdeff", rf"GD, $\eta={eff:.3f}$ $=0.1/(1-e^{{-0.5}})$", lambda: GD(eff)),
    ("hb09", r"Heavy-ball (SGDM), $\beta=0.9$, $\eta=0.1$", lambda: HeavyBall(0.9, 0.1)),
    ("adam", r"Adam, $\eta=10^{-3}$", lambda: Adam(0.001)),
    ("rms", r"RMSprop, $\eta=10^{-3}$, $\rho=0.9$", lambda: RMSprop(0.001, 0.9)),
]
curves = {}
for key, label, mk in METHODS:
    accs, fl, ce_, curve = [], [], [], []
    for s in SEEDS:
        losses, acc, lsnap, _ = run(mk, Xtr, ytr, Xte, yte, s, MAX_EPOCHS)
        accs.append(acc * 100)
        fl.append(lsnap)
        ce_.append(conv_epoch(losses))
        curve.append(losses[:EPOCHS])
    curves[key] = np.array(curve)
    conv = [c for c in ce_ if c is not None]
    results["breast_cancer"][key] = {
        "label": label, "acc": accs, "final_loss": fl, "conv_epoch": ce_,
        "acc_mean": float(np.mean(accs)), "acc_sd": float(np.std(accs, ddof=1)),
    }
    print(f"{key:6s} acc {np.mean(accs):6.2f} +/- {np.std(accs, ddof=1):.2f}  loss {np.mean(fl):.4f}  "
          f"converged {len(conv)}/{len(SEEDS)}")

with open(os.path.join(TAB, "table_R1.tex"), "w", encoding="utf-8") as f:
    f.write("\\begin{tabular}{lccc}\n\\toprule\n")
    f.write("Optimizer & Test accuracy (\\%) & Training loss & Converged by epoch 200 \\\\\n")
    f.write(" & after 100 epochs & after 100 epochs & (runs; median epoch) \\\\\n\\midrule\n")
    for key, label, _ in METHODS:
        r = results["breast_cancer"][key]
        conv = [c for c in r["conv_epoch"] if c is not None]
        conv_txt = f"{len(conv)}/{len(SEEDS)}" + (f"; {np.median(conv):g}" if conv else "; --")
        f.write(f"{label} & {pm(r['acc'])} & {pm(r['final_loss'], 3)} & {conv_txt} \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")

# paired comparisons on accuracy
lines = []
for other in ("gd01", "gdeff", "hb09"):
    a = np.array(results["breast_cancer"]["tfgd"]["acc"])
    b = np.array(results["breast_cancer"][other]["acc"])
    diff = a - b
    if np.allclose(diff, 0):
        lines.append((other, 0.0, 0.0, 0.0, float("nan")))
        continue
    t, p = stats.ttest_rel(a, b)
    ci = stats.t.interval(0.95, len(diff) - 1, loc=diff.mean(), scale=stats.sem(diff))
    lines.append((other, diff.mean(), ci[0], ci[1], p))
    results["breast_cancer"][f"paired_tfgd_minus_{other}"] = {
        "mean_diff": float(diff.mean()), "ci95": [float(ci[0]), float(ci[1])], "t": float(t), "p": float(p)}
names = {"gd01": r"GD with $\eta=0.1$", "gdeff": rf"GD with $\eta={eff:.3f}$",
         "hb09": r"heavy-ball with $\beta=0.9$"}
with open(os.path.join(TAB, "paired_R1.tex"), "w", encoding="utf-8") as f:
    items = []
    for other, m, lo, hi, p in lines:
        if np.isnan(p):
            items.append(f"{names[other]}: identical test accuracy on all {len(SEEDS)} seeds")
            continue
        p_txt = f"{p:.1e}".replace("e-0", "e-").split("e")
        p_tex = f"{p_txt[0]}\\times 10^{{{int(p_txt[1])}}}"
        items.append(f"{names[other]}: ${m:+.2f}$ percentage points "
                     f"(95\\% CI $[{lo:+.2f}, {hi:+.2f}]$, paired $t$-test $p={p_tex}$)")
    f.write("; ".join(items) + ".\n")

# ----------------------------------------------------------------------------- Figure R1
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#52514e", "axes.labelcolor": "#0b0b0b",
                     "xtick.color": "#52514e", "ytick.color": "#52514e"})
fig, ax = plt.subplots(figsize=(6.3, 3.0))
style = [("tfgd", "#2a78d6", "-", r"TFGD as implemented ($\alpha=0.6,\ \lambda=0.5$)"),
         ("gd01", "#eb6834", "--", r"GD, $\eta=0.1$"),
         ("gdeff", "#1baf7a", ":", rf"GD, $\eta={eff:.3f}$")]
ep = np.arange(1, EPOCHS + 1)
for key, col, ls, lab in style:
    m = curves[key].mean(axis=0)
    s = curves[key].std(axis=0, ddof=1)
    ax.fill_between(ep, np.maximum(m - s, 0), m + s, color=col, alpha=0.12, linewidth=0)
    ax.plot(ep, m, color=col, linestyle=ls, linewidth=2, label=lab)
ax.set_xlabel("Epoch")
ax.set_ylabel("Training cross-entropy")
ax.set_xlim(1, EPOCHS)
ax.set_ylim(bottom=0)
ax.grid(axis="y", color="#e6e5e0", linewidth=0.6)
ax.legend(frameon=False, loc="upper right")
fig.tight_layout()
fig.savefig(os.path.join(FIG, "fig_R1_training_loss.pdf"), metadata={"CreationDate": None})  # reproducible bytes
fig.savefig(os.path.join(FIG, "fig_R1_training_loss.png"), dpi=200)
plt.close(fig)

# ----------------------------------------------------------------------------- Table R2 (replaces Table 6)
CONFIGS = [(0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.6, 1.0), (0.9, 0.5)]
params_by_cfg = {}
with open(os.path.join(TAB, "table_R2.tex"), "w", encoding="utf-8") as f:
    f.write("\\begin{tabular}{cccccc}\n\\toprule\n")
    f.write("$\\alpha$ & $\\lambda$ & $\\beta=e^{-\\lambda}$ & Test accuracy (\\%) & "
            "Identical to $\\alpha=0.6$ & Optimizer state \\\\\n")
    f.write(" & & & after 100 epochs & (same $\\lambda$, all seeds) & (bytes) \\\\\n\\midrule\n")
    for a, lam in CONFIGS:
        accs, ps = [], []
        for s in SEEDS:
            _, acc, _, prm = run(lambda: TFGDReleased(a, lam), Xtr, ytr, Xte, yte, s, EPOCHS)
            accs.append(acc * 100)
            ps.append(prm)
        params_by_cfg[(a, lam)] = np.array(ps)
        results["sensitivity"][f"{a}_{lam}"] = {"acc": accs}
    for a, lam in CONFIGS:
        accs = results["sensitivity"][f"{a}_{lam}"]["acc"]
        if a == 0.6:
            same_txt = "(reference)"
        else:
            same = np.array_equal(params_by_cfg[(a, lam)], params_by_cfg[(0.6, lam)])
            same_txt = "yes, bit-identical" if same else "no"
        f.write(f"{a} & {lam} & {np.exp(-lam):.3f} & {pm(accs)} & {same_txt} & {STATE_BYTES} \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")

# ----------------------------------------------------------------------------- Table R3 (replaces Table 7)
X_hd, y_hd = make_classification(n_samples=2000, n_features=1000, n_informative=50, n_redundant=0,
                                 n_repeated=0, n_classes=2, flip_y=0.01, class_sep=1.0, random_state=42)
digits = load_digits()
y_dg = (digits.target == 0).astype(int)
beta03 = np.exp(-0.3)
eff03 = 0.1 / (1 - beta03)
EXTRA_METHODS = [
    ("tfgd", r"TFGD as impl.\ ($\alpha=0.7,\lambda=0.3$)", lambda: TFGDReleased(0.7, 0.3)),
    ("gd01", r"GD, $\eta=0.1$", lambda: GD(0.1)),
    ("gdeff", rf"GD, $\eta={eff03:.3f}$", lambda: GD(eff03)),
]


def prep(Xr, yr):
    Xs = StandardScaler().fit_transform(Xr)
    return train_test_split(Xs, yr, test_size=0.2, random_state=42)


extra_rows = {}
for dname in ("hd", "digits"):
    extra_rows[dname] = {k: [] for k, _, _ in EXTRA_METHODS}
    majority = []
    for s in SEEDS_EXTRA:
        if dname == "hd":
            a_tr, a_te, b_tr, b_te = prep(X_hd, y_hd)
        else:
            noise = np.random.default_rng(10_000 + s).normal(scale=4.0, size=digits.data.shape)
            a_tr, a_te, b_tr, b_te = prep(digits.data + noise, y_dg)
        majority.append(max(b_te.mean(), 1 - b_te.mean()) * 100)
        for k, _, mk in EXTRA_METHODS:
            _, acc, _, _ = run(mk, a_tr, b_tr, a_te, b_te, s, EPOCHS)
            extra_rows[dname][k].append(acc * 100)
    extra_rows[dname]["majority"] = majority
results["extra"] = extra_rows

with open(os.path.join(TAB, "table_R3.tex"), "w", encoding="utf-8") as f:
    f.write("\\begin{tabular}{lcc}\n\\toprule\n")
    f.write("Optimizer & High-dim.\\ synthetic (1000 D) & Noisy digits (0 vs.\\ rest) \\\\\n\\midrule\n")
    for k, label, _ in EXTRA_METHODS:
        f.write(f"{label} & {pm(extra_rows['hd'][k])} & {pm(extra_rows['digits'][k])} \\\\\n")
    f.write(f"Majority-class rate & {np.mean(extra_rows['hd']['majority']):.2f} & "
            f"{np.mean(extra_rows['digits']['majority']):.2f} \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}\n")

for dname in ("hd", "digits"):
    print(dname, {k: f"{np.mean(v):.2f}+/-{np.std(v, ddof=1):.2f}" for k, v in extra_rows[dname].items()})

with open(os.path.join(OUTDIR, "corrigendum_results.json"), "w", encoding="utf-8") as f:
    json.dump(results, f, indent=1, default=float)
print("written:", TAB, FIG)
