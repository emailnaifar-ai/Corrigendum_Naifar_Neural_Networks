# Corrigendum material: Naifar, *Neural Networks* 193 (2026) 108005

This repository holds the verification code and outputs for the proposed corrigendum to

> O. Naifar, "Tempered fractional gradient descent: Theory, algorithms, and robust learning
> applications", *Neural Networks* 193 (2026) 108005, https://doi.org/10.1016/j.neunet.2025.108005

**Original implementation.** The code linked in the article is `TFGD.txt` in
https://github.com/vegaws1/FGD. Its history is unchanged; the last version is commit `1a6d0b5`
(28 June 2025). In every version the update is `S = grad + exp(-lambda) * S; theta -= eta * S`,
which is heavy-ball momentum with beta = exp(-lambda). The fractional order alpha does not enter
the update. The scripts here copy its optimiser, model and training loop (each script names the
lines it copies) and add seeding. `evaluate_eq2.py` also adds what the original repository lacks:
an exact implementation of the update of Eq. (2) of the article, with the full Grünwald–Letnikov
history.

**What the scripts establish** (details in the corrigendum and in `MANIFEST.pdf`):
- the corrected weight sums d = 2-(1-e^-lambda)^alpha and D = alpha e^-lambda (1-e^-lambda)^(alpha-1), and
  the tail bound;
- the counterexample to the published Theorem 4.1, and the errors in Lemma 4.2 and Theorem 4.2;
- numerical checks of the corrected Theorems 4.1 and 4.2: the auxiliary-sequence identity and every
  bound, on convex, non-convex and noisy problems, for Eq. (2) and for the released recursion
  (`verification_output.txt`, section 11);
- that the released code gives bit-identical parameters for every alpha;
- that the standard deviations reported in Tables 2–4 cannot arise from five runs on the test set;
- Tables R1–R5 of the corrigendum (30 or 10 seeds, common initialisation per seed);
- that the released autoencoder script reproduces Fig. 6 of the article.

| File | Purpose |
|---|---|
| `verify_note_claims.py` | Numerical checks of the technical note, of the corrected lemmas and theorems, and of every numerical statement of the corrigendum that does not need training |
| `verification_output.txt` | Output of the script above |
| `reproduce_corrigendum_results.py` | Recomputes Tables R1–R3 and the training-loss curves that replace Fig. 2 (`figures/`), from the released update rule |
| `corrigendum_results.json` | Every number behind Tables R1–R3, per seed |
| `evaluate_eq2.py` | Implements Eq. (2) exactly and compares it with GD with the same step, GD with step eta·d and the released recursion (Tables R4 and R5) |
| `eq2_results.json` | Every number behind Tables R4 and R5, per seed |
| `reproduce_fig6.py` | Re-runs the MNIST autoencoder of Fig. 6 with the released code, in four configurations and three seeds; records the data checksum and the software environment |
| `fig6_results.json` | Output of the script above (loss curves per seed, environment, data SHA-256) |
| `compare_fig6_with_article.py` | Reads Fig. 6 from the article PDF and compares it with the re-run curves |
| `fig6_comparison.json`, `fig6_comparison.txt` | Output of the script above |
| `tables/`, `figures/` | Tables R1–R5 as included in the corrigendum, and the training-loss curves (generated) |
| `MANIFEST.pdf` | Links each statement of the corrigendum to the script, command and output that support it; software versions; SHA-256 of every file |
| `CHECKSUMS_SHA256.txt` | SHA-256 checksums |
| `requirements.txt` | Package versions used to produce the outputs |

## Running

Python 3 with the packages in `requirements.txt` (PyMuPDF is needed only for
`compare_fig6_with_article.py`). In this folder:

```
python verify_note_claims.py > verification_output.txt
python reproduce_corrigendum_results.py --out .
python evaluate_eq2.py --out .
python reproduce_fig6.py --out fig6_results.json
python compare_fig6_with_article.py --pdf ARTICLE.pdf --results fig6_results.json --out fig6_comparison.json > fig6_comparison.txt
```

The first three take about a minute each. `reproduce_fig6.py` runs configurations a–d with seeds
0, 1, 2 by default, about 50 minutes in total (`--configs a --seeds 0` runs the released script
once, about 10 minutes on a laptop CPU). It reads MNIST from keras if installed, otherwise from a
keras-format `mnist.npz` given with `--npz`, otherwise from scikit-learn's OpenML copy, and records
the SHA-256 of the 60,000 x 784 uint8 training images it used, so that runs on different machines
can be checked to use the same data. `ARTICLE.pdf` is the published article, which is not included
here.
