"""
Independent checks of the points raised in the technical note on
O. Naifar, "Tempered fractional gradient descent: Theory, algorithms, and
robust learning applications", Neural Networks 193 (2026) 108005.

Run:   python verify_note_claims.py > verification_output.txt
Needs: numpy, scipy, scikit-learn  (no GPU, about 1 minute)

Sections
  1. Theorem 4.1 counterexample (theta^2/2)
  2. Definition 2.2 vs Lemma 4.1: which coefficients have generating fn (1-z)^-alpha
  3. Eq. (21)/Table 1 recursion: what weights it actually produces
  4. Released code (TFGD.txt, commit 1a6d0b5): alpha-independence of the sweep
  5. Released code: TFGD vs SGD vs SGD with matched effective step size
  6. Lemma 4.2 bound vs its own j=0 term
  7. Theorem 4.2 proof: sum of eta_k^2 with eta_k = eta0 / k^(alpha/2)
  8. Arithmetic consistency of reported mean +/- SD (5 runs) with the test-set size
  9. Same check for Table 7 (single runs)
 10. Lemma 5.2, Remark 2 and Fig. 1: elementary checks
 11. Corrected Theorems 4.1 and 4.2: constants d and D, the identity of Lemma C1, and the bounds on
     convex, non-convex and noisy test problems, for Eq. (2) and for the released recursion
"""
import itertools
import math

import numpy as np
from scipy.special import binom, gamma, poch
from sklearn.datasets import load_breast_cancer
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

np.set_printoptions(precision=6, suppress=True, linewidth=120)


def hdr(title):
    print("\n" + "=" * 78 + "\n" + title + "\n" + "=" * 78)


def d_paper(a, lam):
    """Alignment coefficient of Lemma 4.1: (1 - e^-lambda)^-alpha."""
    return (1.0 - np.exp(-lam)) ** (-a)


def abs_gl(a, J):
    """|binom(alpha, j)|, j = 0..J-1  (the weights of Definition 2.2)."""
    return np.abs(binom(a, np.arange(J)))


def frac_sum(a, J):
    """Coefficients of (1 - z)^(-alpha): (alpha)_j / j!  (fractional summation).
    Computed by the stable recursion c_0 = 1, c_j = c_{j-1} (j - 1 + alpha) / j."""
    c = np.ones(J)
    for j in range(1, J):
        c[j] = c[j - 1] * (j - 1 + a) / j
    return c


# --------------------------------------------------------------------------
hdr("1. Theorem 4.1 counterexample: L(theta)=theta^2/2, theta0=1, L=1, theta*=0, eta=1/L=1")
print("K * LHS of Eq.(7) >= L(theta0) - L* = 0.5 for every K (all terms are >= 0).")
print("K * RHS of Eq.(7) = 1/(2d) + C*K*exp(-lambda*K)/(lambda*d)  ->  1/(2d) as K -> inf.")
print("So the theorem fails for large K whenever d > 1.\n")
print(f"{'alpha':>6} {'lambda':>7} {'d_alpha,lambda':>15} {'lim K*RHS':>10}  violated?")
for a in (0.1, 0.3, 0.6, 0.9, 0.99):
    for lam in (0.01, 0.1, 0.5, 1.0, 5.0):
        d = d_paper(a, lam)
        print(f"{a:6.2f} {lam:7.2f} {d:15.6f} {1 / (2 * d):10.6f}  {'YES' if 1 / (2 * d) < 0.5 else 'no'}")

grid_a = np.linspace(0.001, 0.999, 999)
grid_l = np.logspace(-4, 2, 1000)
A, Lm = np.meshgrid(grid_a, grid_l)
print(f"\nmin of d over alpha in (0,1), lambda in [1e-4, 100]: {d_paper(A, Lm).min():.10f}  (> 1)")


def run_on_quadratic(weights_fn, a, lam, K, eta=1.0):
    """theta_{k+1} = theta_k - eta * sum_j w_j e^{-lambda j} grad(theta_{k-j}), grad = theta."""
    th = [1.0]
    w = weights_fn(a, K + 1) * np.exp(-lam * np.arange(K + 1))
    for k in range(K):
        hist = np.array(th[::-1])  # theta_k, theta_{k-1}, ..., theta_0
        step = float(np.dot(w[: k + 1], hist))
        th.append(th[-1] - eta * step)
        if not np.isfinite(th[-1]) or abs(th[-1]) > 1e150:
            break
    return np.array(th[:K])


def run_code_recursion(a, lam, K, eta=1.0):
    """Exactly the released update: S = grad + e^-lambda * S ; theta -= eta * S."""
    th, S, out = 1.0, 0.0, []
    for _ in range(K):
        out.append(th)
        S = th + np.exp(-lam) * S
        th = th - eta * S
    return np.array(out)


K, C = 200, 1e6
print(f"\nSimulated trajectories, K={K}, any constant C (here C={C:g}):")
print(f"{'alpha':>6} {'lambda':>7} {'variant':<34} {'K*LHS':>12} {'K*RHS':>10}")
for a, lam in ((0.6, 0.5), (0.3, 0.5), (0.9, 0.5), (0.6, 0.1), (0.6, 1.0)):
    d = d_paper(a, lam)
    krhs = 1 / (2 * d) + C * K * np.exp(-lam * K) / (lam * d)
    for name, traj in (
        ("released code recursion", run_code_recursion(a, lam, K)),
        ("Eq.(2), |binom(alpha,j)| weights", run_on_quadratic(abs_gl, a, lam, K)),
        ("Eq.(2), (1-z)^-alpha coefficients", run_on_quadratic(frac_sum, a, lam, K)),
    ):
        with np.errstate(over="ignore", invalid="ignore"):
            klhs = float(np.sum(traj ** 2 / 2))
        if not np.isfinite(klhs) or len(traj) < K:
            print(f"{a:6.2f} {lam:7.2f} {name:<34} {'diverges':>12} {krhs:10.4f}  VIOLATED")
        else:
            print(f"{a:6.2f} {lam:7.2f} {name:<34} {klhs:12.4g} {krhs:10.4f}  {'VIOLATED' if klhs > krhs else 'ok'}")

print("\nKnown result for the implemented recursion (heavy-ball, beta = e^-lambda), cited but not restated")
print("in the corrigendum; numerical sanity check only:")
print("Ghadimi et al. (2015, Thm 1): for eta in (0, (1-beta)/L], with theta_bar_K = mean(theta_0..theta_K),")
print("  L(theta_bar_K) - L* <= ||theta0-theta*||^2 / (2(K+1)) * (L beta/(1-beta) + (1-beta)/eta)")
rng_q = np.random.default_rng(1)
Q = rng_q.standard_normal((20, 20))
H = Q.T @ Q / 20 + 0.0 * np.eye(20)  # convex quadratic, possibly ill-conditioned
Lq = np.linalg.eigvalsh(H).max()
x0 = rng_q.standard_normal(20)
for lam in (0.1, 0.5, 1.0):
    beta = np.exp(-lam)
    eta = (1 - beta) / Lq
    x, S, xs = x0.copy(), np.zeros(20), []
    for _ in range(501):
        xs.append(x.copy())
        S = H @ x + beta * S
        x = x - eta * S
    worst = 0.0
    for Kk in (10, 50, 100, 500):
        xb = np.mean(xs[: Kk + 1], axis=0)
        gap = 0.5 * xb @ H @ xb
        bound = (x0 @ x0) / (2 * (Kk + 1)) * (Lq * beta / (1 - beta) + (1 - beta) / eta)
        worst = max(worst, gap / bound)
    print(f"  lambda={lam}: max over K of gap/bound = {worst:.4f}  ({'holds' if worst <= 1 else 'FAILS'})")

# --------------------------------------------------------------------------
hdr("2. Definition 2.2 vs Lemma 4.1 (generating functions)")
a = 0.6
J = 6
print(f"alpha = {a}")
print("j                       :", np.arange(J))
print("|binom(alpha,j)| (Def2.2):", abs_gl(a, J))
print("coeffs of (1-z)^-alpha   :", frac_sum(a, J))
print(f"lag 2: alpha(1-alpha)/2 = {a * (1 - a) / 2:.6f},  alpha(1+alpha)/2 = {a * (1 + a) / 2:.6f}")
z = 0.37
Jbig = 20000
print(f"\nAt z = {z}:  sum |binom(alpha,j)| z^j = {np.sum(abs_gl(a, Jbig) * z ** np.arange(Jbig)):.10f}")
print(f"            2 - (1-z)^alpha           = {2 - (1 - z) ** a:.10f}")
print(f"            (1-z)^-alpha  [Eq. (6)]   = {(1 - z) ** (-a):.10f}")
print("\nTempered sums sum_j |binom(alpha,j)| e^{-lambda j}  vs  d of Lemma 4.1:")
for a, lam in ((0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.6, 1.0), (0.9, 0.5)):
    s = np.sum(abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig)))
    print(f"  alpha={a}, lambda={lam}: actual sum = {s:.6f}"
          f"  = 2-(1-e^-l)^a = {2 - (1 - np.exp(-lam)) ** a:.6f};  Lemma 4.1 d = {d_paper(a, lam):.6f}")
print("\nTail behaviour used in the proof of Lemma 4.1 (j = 1000):")
a, j = 0.6, 1000
print(f"  |binom(alpha,j)|      = {abs_gl(a, j + 1)[-1]:.3e}   ~ alpha j^-(1+alpha)/Gamma(1-alpha) = {a * j ** (-1 - a) / gamma(1 - a):.3e}")
print(f"  (1-z)^-alpha coeff    = {frac_sum(a, j + 1)[-1]:.3e}   ~ j^(alpha-1)/Gamma(alpha)          = {j ** (a - 1) / gamma(a):.3e}")
print("  -> the proof sums one sequence but bounds the tail of the other.")

print("\nCorrected tail bound (used in the corrigendum):")
print("  R_k = sum_{j>k} |binom(a,j)| e^{-l j} <= a e^{-l(k+1)} / ((k+1)^(1+a) (1-e^{-l}))")
print("  (uses |binom(a,j)| <= a j^-(1+a), j >= 1)")
for a in (0.05, 0.3, 0.6, 0.9, 0.99):
    w = abs_gl(a, 100000)
    jj = np.arange(1, 100000)
    print(f"  alpha={a}: max_j |binom(a,j)| j^(1+a) / a = {np.max(w[1:] * jj ** (1 + a)) / a:.6f}  (<= 1 required)")
for a, lam in ((0.3, 0.5), (0.6, 0.1), (0.6, 0.5), (0.9, 1.0), (0.01, 0.01), (0.99, 2.0)):
    w = abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig))
    worst = 0.0
    for k in range(0, 400):
        Rk = np.sum(w[k + 1:])
        bound = a * np.exp(-lam * (k + 1)) / ((k + 1) ** (1 + a) * (1 - np.exp(-lam)))
        if bound < 1e-250:  # both sides underflow in double precision beyond this point
            break
        worst = max(worst, Rk / bound)
    print(f"  alpha={a}, lambda={lam}: max_(k<400) R_k / bound = {worst:.4f}  ({'holds' if worst <= 1 else 'FAILS'})")
a, lam, k = 0.6, 0.5, 20
w = abs_gl(a, Jbig) * np.exp(-lam * np.arange(Jbig))
print(f"  example (alpha, lambda, k) = (0.6, 0.5, 20): R_k = {np.sum(w[k + 1:]):.3e}, "
      f"bound = {a * np.exp(-lam * (k + 1)) / ((k + 1) ** (1 + a) * (1 - np.exp(-lam))):.3e}")
print("\nProof of Theorem 4.1, error (iv): Eq. (1) with a constant gradient g gives lambda^(alpha-1) g, whereas")
print("the weights of Eq. (2) up to lag k sum to (1, 1.364, 1.408, ...) -> d:")
a, lam = 0.6, 0.5
ps = np.cumsum(abs_gl(a, 6) * np.exp(-lam * np.arange(6)))
print(f"  (0.6, 0.5): lambda^(alpha-1) = {lam ** (a - 1):.4f};  partial sums k=0..5: "
      + ", ".join(f"{p:.3f}" for p in ps) + f";  d = {2 - (1 - np.exp(-lam)) ** a:.4f}")

# --------------------------------------------------------------------------
hdr("3. Recursion of Eq. (21) / Table 1: S_k = |w_0| g_k + e^-lambda S_{k-1}, |w_0| = 1")
rng = np.random.default_rng(0)
Kr = 400
g = rng.standard_normal(Kr + 1)
for a, lam in ((0.1, 0.5), (0.6, 0.5), (0.9, 0.5)):
    S = 0.0
    for k in range(Kr + 1):
        S = binom(a, 0) * g[k] + np.exp(-lam) * S
    j = np.arange(Kr + 1)
    geo = np.sum(np.exp(-lam * j) * g[::-1])
    tfd_abs = np.sum(abs_gl(a, Kr + 1) * np.exp(-lam * j) * g[::-1])
    tfd_sum = np.sum(frac_sum(a, Kr + 1) * np.exp(-lam * j) * g[::-1])
    print(f"alpha={a}: recursion S_k = {S:+.12f} | sum e^-lj g = {geo:+.12f} | "
          f"sum |binom| e^-lj g = {tfd_abs:+.6f} | sum (1-z)^-a coeff e^-lj g = {tfd_sum:+.6f}")
print("-> The recursion reproduces the geometric weights e^{-lambda j} exactly and is the same for every alpha.")
print("   Its gap to either fractional sum is a fixed per-lag weight difference (lag 1: 1 vs alpha),")
print("   so it does not shrink like O(e^{-lambda k}/k^{1+alpha}) as Lemma 5.1 states.")

# --------------------------------------------------------------------------
hdr("4. Released code, sensitivity sweep (TFGD.txt lines 112-217, commit 1a6d0b5), seeded")
LEARNING_RATE = 0.1
MAX_EPOCHS = 200
CONV_THRESHOLD = 1e-4
CONV_PATIENCE = 5

data = load_breast_cancer()
X, y = data.data, data.target
X = StandardScaler().fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(f"n_train = {len(y_train)}, n_test = {len(y_test)}")


def sigmoid(zz):
    return 1 / (1 + np.exp(-zz))


def cross_entropy_loss(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + 1e-8) + (1 - y_true) * np.log(1 - y_pred + 1e-8))


class TFGDOptimizer:  # verbatim from TFGD.txt lines 146-157
    def __init__(self, alpha, lambd):
        self.alpha = alpha
        self.lambd = lambd
        self.S = None

    def update(self, params, grads):
        if self.S is None:
            self.S = np.zeros_like(params)
        self.S = grads + np.exp(-self.lambd) * self.S
        return params - LEARNING_RATE * self.S


class HeavyBall:  # PyTorch SGD(momentum=beta, dampening=0) form: v = beta v + g; p -= lr v
    def __init__(self, beta, lr):
        self.beta, self.lr, self.v = beta, lr, None

    def update(self, params, grads):
        if self.v is None:
            self.v = np.zeros_like(params)
        self.v = self.beta * self.v + grads
        return params - self.lr * self.v


class PlainGD:
    def __init__(self, lr):
        self.lr = lr

    def update(self, params, grads):
        return params - self.lr * grads


class LogisticRegression:  # verbatim from TFGD.txt lines 160-172
    def __init__(self, dim):
        self.w = np.random.randn(dim)
        self.b = np.random.randn()

    def forward(self, Xx):
        return sigmoid(Xx @ self.w + self.b)

    def grads(self, Xx, y_true, y_pred):
        err = y_pred - y_true
        dw = (Xx.T @ err) / len(y_true)
        db = np.mean(err)
        return dw, db


def train_and_evaluate(make_opt, max_epochs=MAX_EPOCHS, early_stop=True):
    """TFGD.txt lines 175-202, with the optimiser factory made a parameter."""
    model = LogisticRegression(X_train.shape[1])
    opt_w, opt_b = make_opt(), make_opt()
    losses = []
    conv_epoch = max_epochs
    for epoch in range(1, max_epochs + 1):
        y_pred = model.forward(X_train)
        losses.append(cross_entropy_loss(y_train, y_pred))
        dw, db = model.grads(X_train, y_train, y_pred)
        model.w = opt_w.update(model.w, dw)
        model.b = opt_b.update(model.b, db)
        if early_stop and epoch > CONV_PATIENCE:
            if np.all(np.abs(np.diff(losses[-CONV_PATIENCE:])) < CONV_THRESHOLD):
                conv_epoch = epoch
                break
    acc = accuracy_score(y_test, (model.forward(X_test) > 0.5).astype(int))
    return acc, conv_epoch, model


print("\nSame seed (0) for every alpha, lambda = 0.5:")
ref = None
for a in np.linspace(0.1, 1.0, 10):
    np.random.seed(0)
    acc, ep, m = train_and_evaluate(lambda: TFGDOptimizer(a, 0.5))
    params = np.append(m.w, m.b)
    if ref is None:
        ref = params
    print(f"  alpha={a:.1f}: acc={acc:.4f}  conv_epoch={ep}  max|params - params(alpha=0.1)| = {np.max(np.abs(params - ref)):.1e}")

np.random.seed(0)
_, _, m_tfgd = train_and_evaluate(lambda: TFGDOptimizer(0.6, 0.5))
np.random.seed(0)
_, _, m_hb = train_and_evaluate(lambda: HeavyBall(np.exp(-0.5), LEARNING_RATE))
print(f"\nReleased TFGD(alpha=0.6, lambda=0.5) vs heavy-ball momentum beta=e^-0.5={np.exp(-0.5):.4f}, same seed:")
print(f"  max |param difference| = {np.max(np.abs(np.append(m_tfgd.w, m_tfgd.b) - np.append(m_hb.w, m_hb.b))):.1e}")

print("\nSeeded stand-ins (seeds 1000-1499) for the unseeded runs of the released script, alpha=0.6, lambda=0.5:")
accs, eps_ = [], []
for s in range(500):
    np.random.seed(1000 + s)
    acc, ep, _ = train_and_evaluate(lambda: TFGDOptimizer(0.6, 0.5))
    accs.append(acc)
    eps_.append(ep)
accs = np.array(accs)
print(f"  test accuracy: min {accs.min():.4f}  max {accs.max():.4f}  mean {accs.mean():.4f}  sd {accs.std(ddof=1):.4f}")
vals, cnts = np.unique(np.round(accs * 114).astype(int), return_counts=True)
print("  frequency of each accuracy: " + ", ".join(f"{v}/114 = {100 * v / 114:.2f}%: {c}" for v, c in zip(vals, cnts)))
print(f"  convergence epoch: min {min(eps_)}  max {max(eps_)}  (published Fig. 5 panel (a) spans 0.938-0.991)")
n_low = int(np.sum(np.round(accs * 114).astype(int) == 107))
print("  -> alpha does not enter the update (bit-identical parameters above), so the variation over alpha in the")
print(f"     published code-generated figure is seed noise; its lowest value, 107/114 = 0.9386, occurs in {n_low} of these 500 runs.")

# --------------------------------------------------------------------------
hdr("5. Released code, main protocol (100 epochs, lr 0.1): seeds 0-29 (same as corrigendum Table R1)")
eff_lr = LEARNING_RATE / (1 - np.exp(-0.5))
rows = (
    ("TFGD as released (alpha=0.6, lambda=0.5)", lambda: TFGDOptimizer(0.6, 0.5)),
    ("plain GD, lr=0.1", lambda: PlainGD(0.1)),
    (f"plain GD, lr={eff_lr:.4f} (= 0.1/(1-e^-0.5))", lambda: PlainGD(eff_lr)),
    ("heavy-ball beta=0.9, lr=0.1", lambda: HeavyBall(0.9, 0.1)),
)
for name, mk in rows:
    res = []
    for s in range(30):
        np.random.seed(s)
        res.append(train_and_evaluate(mk, max_epochs=100, early_stop=False)[0])
    res = np.array(res) * 100
    print(f"  {name:<46} acc = {res.mean():6.2f} +/- {res.std(ddof=1):4.2f} %   [min {res.min():.2f}, max {res.max():.2f}]")
print("  Published Table 2: TFGD 98.25 +/- 0.31 %, SGD 92.11 +/- 0.87 %.")

# --------------------------------------------------------------------------
hdr("6. Lemma 4.2: sum_j |w_j|^2 e^{-2 lambda j} <= Gamma(1+2a) / ((2 lambda)^{2a} Gamma(1+a)^2)")
print("The j = 0 term alone equals |w_0|^2 = 1, so the bound fails whenever the RHS < 1.")
for a in (0.3, 0.6, 0.9):
    for lam in (0.1, 0.5, 1.0, 2.0):
        rhs = gamma(1 + 2 * a) / ((2 * lam) ** (2 * a) * gamma(1 + a) ** 2)
        lhs_abs = np.sum(abs_gl(a, 5000) ** 2 * np.exp(-2 * lam * np.arange(5000)))
        lhs_sum = np.sum(frac_sum(a, 5000) ** 2 * np.exp(-2 * lam * np.arange(5000)))
        bad = "FALSE" if min(lhs_abs, lhs_sum) > rhs else "holds"
        print(f"  alpha={a}, lambda={lam}: RHS={rhs:7.4f}  LHS(|binom|)={lhs_abs:7.4f}  LHS((1-z)^-a)={lhs_sum:7.4f}  -> {bad}")

from scipy.special import hyp2f1  # noqa: E402

print("\nCorrected statement (used in the corrigendum):")
print("  sum_j binom(a,j)^2 z^j = 2F1(-a,-a;1;z)  <= min{ Gamma(1+2a)/Gamma(1+a)^2 (Gauss, z=1),  1 + a^2 z/(1-z) }"
      "   (z = e^{-2 lambda})")
for a in (0.3, 0.6, 0.9):
    gauss = gamma(1 + 2 * a) / gamma(1 + a) ** 2
    for lam in (0.01, 0.1, 0.5, 1.0):
        zz = np.exp(-2 * lam)
        lhs = np.sum(abs_gl(a, 200000) ** 2 * zz ** np.arange(200000))
        simple = 1 + a * a * zz / (1 - zz)
        print(f"  alpha={a}, lambda={lam}: series={lhs:.10f}  2F1={hyp2f1(-a, -a, 1, zz):.10f}  "
              f"Gauss bound={gauss:.6f}  simple bound={simple:.6f}  "
              f"({'holds' if lhs <= min(gauss, simple) + 1e-12 else 'FAILS'})")
print(f"  check of Gauss's theorem at alpha=0.6: sum_j binom(0.6,j)^2 (2e6 terms) = "
      f"{np.sum(abs_gl(0.6, 2000000) ** 2):.10f},  Gamma(2.2)/Gamma(1.6)^2 = {gamma(2.2) / gamma(1.6) ** 2:.10f}")

from scipy.integrate import quad  # noqa: E402

print("\nEqs. (14) and (15) of the proof, evaluated at z = e^{-2 lambda}, against the true sum:")
print("  Eq. (14): (1-z)^(-2a) 2F1(a, a; 1; z^2/(1-z)^2)")
print("  Eq. (15): Gamma(1+2a)/Gamma(1+a)^2 * int_0^1 t^(a-1) (1-t)^(a-1) e^(-2 lambda t) dt")
for a, lam in ((0.6, 0.5), (0.6, 1.0)):
    zz = np.exp(-2 * lam)
    true_sum = hyp2f1(-a, -a, 1, zz)
    eq14 = (1 - zz) ** (-2 * a) * hyp2f1(a, a, 1, zz ** 2 / (1 - zz) ** 2)
    integral = quad(lambda t: np.exp(-2 * lam * t), 0, 1, weight="alg", wvar=(a - 1, a - 1))[0]
    eq15 = gamma(1 + 2 * a) / gamma(1 + a) ** 2 * integral
    print(f"  alpha={a}, lambda={lam}: true sum = {true_sum:.5f}   Eq.(14) = {eq14:.5f}   Eq.(15) = {eq15:.5f}"
          f"   -> {'both incorrect' if min(abs(eq14 - true_sum), abs(eq15 - true_sum)) > 1e-3 else 'CHECK'}")

# --------------------------------------------------------------------------
hdr("7. Theorem 4.2 proof: 'sum eta_k^2 <= C eta0^2' with eta_k = eta0 / k^(alpha/2)")
for a in (0.3, 0.6, 0.9):
    parts = [np.sum(np.arange(1, Kk + 1, dtype=float) ** (-a)) for Kk in (10 ** 2, 10 ** 4, 10 ** 6)]
    print(f"  alpha={a}: sum_(k<=K) k^-alpha for K=1e2,1e4,1e6: " + ", ".join(f"{p:,.1f}" for p in parts) + "  (diverges)")
print("Dividing the final inequality of the proof by K: first term ~ K^(alpha/2 - 1), claimed rate K^(-alpha).")
for a in (0.3, 2 / 3, 0.9):
    Kk = 1e6
    print(f"  alpha={a:.3f}: K^(alpha/2-1) / K^(-alpha) at K=1e6 = {Kk ** (a / 2 - 1) / Kk ** (-a):.3g}"
          f"  ({'not O(K^-alpha)' if a > 2 / 3 + 1e-12 else 'within O(K^-alpha)'})")
print("Averaged noise term (C sigma^2 / K) sum_{k=1}^K e^{-2 lambda k} >= C sigma^2 e^{-2 lambda} / K, i.e. order 1/K.")

# --------------------------------------------------------------------------
hdr("8. Can the reported mean +/- SD be the result of 5 runs on the test set?")
print("Accuracy on n_test samples is (correct)/n_test. For each reported pair we enumerate every")
print("5-tuple of correct counts and accept if mean AND SD (ddof 0 or 1) match within 0.01 %-points")
print("(more lenient than 2-decimal rounding). n_test = 114 (80/20 split, as in the code) and")
print("n_test = 57 (80/10/10 split, as stated in Section 6).\n")
reported = [
    ("Table 2/3/6  TFGD (0.6,0.5)", 98.25, 0.31),
    ("Table 2/4    SGD", 92.11, 0.87),
    ("Table 3      Adam", 69.30, 3.15),
    ("Table 3      RMSprop", 92.98, 0.92),
    ("Table 4      SGDM", 94.74, 0.42),
    ("Table 4      Zhou-FGD", 95.61, 0.58),
    ("Table 4      Shin-FAdam", 96.49, 0.37),
    ("Table 6      (0.3,0.5)", 97.81, 0.42),
    ("Table 6      (0.6,0.1)", 98.72, 0.28),
    ("Table 6      (0.6,1.0)", 96.33, 0.49),
    ("Table 6      (0.9,0.5)", 98.40, 0.33),
]
TOL = 0.01


def consistent(mean_pct, sd_pct, n, runs=5):
    c = mean_pct / 100 * n
    R = max(6, int(math.ceil(4 * sd_pct / 100 * n)) + 3)
    lo, hi = max(0, int(round(c)) - R), min(n, int(round(c)) + R)
    combos = np.array(list(itertools.combinations_with_replacement(range(lo, hi + 1), runs)), dtype=float)
    acc = combos / n * 100
    mu = acc.mean(axis=1)
    ok_mu = np.abs(mu - mean_pct) <= TOL
    if not ok_mu.any():
        return False, "mean impossible"
    sd0 = acc[ok_mu].std(axis=1, ddof=0)
    sd1 = acc[ok_mu].std(axis=1, ddof=1)
    if (np.abs(sd0 - sd_pct) <= TOL).any() or (np.abs(sd1 - sd_pct) <= TOL).any():
        return True, "ok"
    near = np.unique(np.round(np.concatenate([sd0, sd1]), 2))
    near = near[np.argsort(np.abs(near - sd_pct))][:3]
    return False, "SD impossible (nearest attainable: " + ", ".join(f"{v:.2f}" for v in sorted(near)) + ")"


print(f"{'row':<30} {'reported':>14}   {'n_test=114':<46} {'n_test=57'}")
for name, m, s in reported:
    r114 = consistent(m, s, 114)
    r57 = consistent(m, s, 57)
    single = any(abs(k / 114 * 100 - m) <= TOL for k in range(115))
    print(f"{name:<30} {m:6.2f} +/- {s:4.2f}   {('OK' if r114[0] else r114[1]):<46} {('OK' if r57[0] else r57[1])}"
          f"   [single run on 114 possible: {'yes' if single else 'no'}]")


def attainable_sds(n, below=1.0, runs=5, span=15):
    """Every SD (ddof 0 or 1, rounded to 2 decimals) of `runs` accuracies on n samples, below `below` %.
    The SD does not depend on the mean, so it suffices to enumerate tuples whose minimum is 0."""
    vals = set()
    for c in itertools.combinations_with_replacement(range(span), runs):
        if c[0] != 0:
            continue
        acc = np.array(c) / n * 100
        for dd in (0, 1):
            s = round(float(np.std(acc, ddof=dd)), 2)
            if s < below:
                vals.add(s)
    return sorted(vals)


print("\nStandard deviations of five runs that can occur at all (any mean), rounded to two decimals, below 1 %:")
rep_sds = {"TFGD": 0.31, "RMSprop": 0.92, "SGDM": 0.42, "Zhou-FGD": 0.58, "Shin-FAdam": 0.37}
for n in (114, 57, 56):
    v = attainable_sds(n)
    hits = [k for k, s in rep_sds.items() if s in v]
    print(f"  n_test={n}: {', '.join(f'{x:.2f}' for x in v)}")
    print(f"    reported SDs among them: {hits if hits else 'none'}")
k570 = np.arange(571)
print(f"Five-run means are multiples of 1/570; {int(np.sum(k570 % 5 == 0))} of the 571 possible values are also "
      f"single-run values k/114 (about one in five).")
print("Mean accuracies reported in Tables 2-4, compared with single-run values k/114:")
for m in (98.25, 92.11, 69.30, 92.98, 94.74, 95.61, 96.49):
    k = round(m / 100 * 114)
    print(f"  {m:6.2f}%  ~ {k}/114 = {k / 114 * 100:.4f}%  (agrees to two decimals: {'yes' if abs(k / 114 * 100 - m) < 0.005 else 'no'})")

# --------------------------------------------------------------------------
hdr("9. Table 7 (single runs): granularity check")
for name, val, n in (("High-dim synthetic TFGD", 61.25, 400), ("High-dim synthetic SGD", 49.00, 400),
                     ("Noisy digits TFGD", 95.83, 360), ("Noisy digits SGD", 75.83, 360)):
    k = round(val / 100 * n)
    print(f"  {name:<26} {val:6.2f}%  n_test={n}:  {k}/{n} = {k / n * 100:.4f}%  -> {'consistent' if abs(k / n * 100 - val) < 0.006 else 'INCONSISTENT'}")

# --------------------------------------------------------------------------
hdr("10. Lemma 5.2, Remark 2 and Fig. 1: elementary checks")
lams = np.linspace(0.01, 5, 500)
print(f"1 - e^-lambda < lambda for every lambda in [0.01, 5]: {bool(np.all(1 - np.exp(-lams) < lams))}"
      "  -> (1-e^{-lK})/(1-e^{-l}) <= (1-e^{-lK})/l in the proof of Lemma 5.2 is reversed")
print(f"1 - e^-lambda >= lambda/2 holds for lambda in [0.01, 1.59]: {bool(np.all(1 - np.exp(-lams[lams <= 1.59]) >= lams[lams <= 1.59] / 2))}"
      "  -> it gives only (1-e^{-lK})/(1-e^{-l}) <= 2(1-e^{-lK})/l")
jmax_vals = np.exp(-lams * np.ceil(5 / lams))
print(f"Remark 2: max over lambda of e^(-lambda * ceil(5/lambda)) = {jmax_vals.max():.4e} (= e^-5 = {np.exp(-5):.4e}"
      f" when 5/lambda is an integer), not < 1e-5")
print("Fig. 1 values of the formula d/lambda with d = 30: " +
      ", ".join(f"lambda={l}: {30 / l:g}" for l in (0.1, 0.5, 1.0)))
S_w = np.zeros(30)      # optimiser buffer for the 30 weights (released code: np.zeros_like(params))
S_b = np.zeros_like(0.0)  # optimiser buffer for the bias
print(f"Released optimiser state for logistic regression: two buffers, {S_w.size} + {S_b.size} = {S_w.size + S_b.size} "
      f"float64 values = {S_w.nbytes + S_b.nbytes} bytes of data, for every alpha and lambda")

# --------------------------------------------------------------------------
hdr("11. Corrected Theorems 4.1 and 4.2 (corrigendum Section C3): constants, identity of Lemma C1, bounds")
# Iteration theta_{k+1} = theta_k - eta * sum_{j=0}^k a_j g_{k-j} with a_j >= 0, d = sum a_j, D = sum j a_j.
# Eq. (2): a_j = |binom(alpha, j)| e^{-lambda j};  released recursion (heavy ball): a_j = e^{-lambda j}.
from scipy.optimize import minimize  # noqa: E402


def kernel_eq2(a, lam, J):
    return abs_gl(a, J) * np.exp(-lam * np.arange(J))


def d_D_eq2(a, lam):
    q = np.exp(-lam)
    return 2 - (1 - q) ** a, a * q * (1 - q) ** (a - 1)


print("Closed forms d = 2-(1-q)^a, D = a q (1-q)^(a-1), q = e^-lambda, against the series (20000 terms):")
for a, lam in ((0.3, 0.1), (0.6, 0.5), (0.9, 1.0), (0.6, 0.1), (0.99, 0.05)):
    w = kernel_eq2(a, lam, 20000)
    d_cf, D_cf = d_D_eq2(a, lam)
    print(f"  alpha={a:<4} lambda={lam:<4}: d = {d_cf:.6f} (series {w.sum():.6f}),"
          f"  D = {D_cf:.6f} (series {(np.arange(w.size) * w).sum():.6f}),  1/(d+2D) = {1 / (d_cf + 2 * D_cf):.4f}")

rng = np.random.default_rng(2026)
n = 20
# P1: convex quadratic, L = 1
Qm, _ = np.linalg.qr(rng.standard_normal((n, n)))
A = Qm @ np.diag(np.geomspace(1e-2, 1.0, n)) @ Qm.T
bq = rng.standard_normal(n)
th_star_q = np.linalg.solve(A, bq)
P1 = dict(name="convex quadratic", L=1.0,
          f=lambda t: 0.5 * np.einsum("...i,ij,...j->...", t, A, t) - t @ bq,
          g=lambda t: t @ A - bq, convex=True, theta_star=th_star_q)
P1["f_inf"] = float(P1["f"](th_star_q))
# P2: logistic regression (convex), L = ||X||^2 / (4 m)
Xl = rng.standard_normal((200, n))
sl = np.where(Xl @ rng.standard_normal(n) + 2.0 * rng.standard_normal(200) > 0, 1.0, -1.0)


def f_log(t):
    return np.mean(np.logaddexp(0.0, -sl * (t @ Xl.T)), axis=-1)


def g_log(t):
    return -((sl / (1.0 + np.exp(sl * (t @ Xl.T)))) @ Xl) / Xl.shape[0]


opt = minimize(f_log, np.zeros(n), jac=g_log, method="BFGS", options={"gtol": 1e-13, "maxiter": 10000})
P2 = dict(name="logistic regression", L=np.linalg.norm(Xl, 2) ** 2 / (4 * Xl.shape[0]), f=f_log, g=g_log,
          convex=True, theta_star=opt.x, f_inf=float(opt.fun))
# P3: non-convex robust regression, f = mean log(1 + (B t - c)^2), L <= 2 ||B||^2 / m, inf f = 0 (B has full row rank)
Bn = rng.standard_normal((10, n))
cn = 3.0 * rng.standard_normal(10)


def f_nc(t):
    r = t @ Bn.T - cn
    return np.mean(np.log1p(r ** 2), axis=-1)


def g_nc(t):
    r = t @ Bn.T - cn
    return (2 * r / (1 + r ** 2)) @ Bn / Bn.shape[0]


P3 = dict(name="non-convex log(1+r^2)", L=2 * np.linalg.norm(Bn, 2) ** 2 / Bn.shape[0], f=f_nc, g=g_nc,
          convex=False, f_inf=0.0)
theta0 = 3.0 * rng.standard_normal(n)


def run_memory(prob, a_w, eta, K, sigma=0.0, reps=1, seed=0):
    """Exact iteration with full history. Returns iterates (K+1, reps, n), true gradients and noisy gradients (K, reps, n)."""
    r = np.random.default_rng(seed)
    th = np.tile(theta0, (reps, 1))
    TH, G, Gt = [th], np.zeros((K, reps, n)), np.zeros((K, reps, n))
    for k in range(K):
        G[k] = prob["g"](th)
        Gt[k] = G[k] + (sigma / np.sqrt(n)) * r.standard_normal((reps, n)) if sigma > 0 else G[k]
        th = th - eta * np.tensordot(a_w[:k + 1], Gt[k::-1], axes=(0, 0))
        TH.append(th)
    return np.array(TH), G, Gt


K = 300
kernels = [("Eq. (2)", a, lam) for a, lam in ((0.3, 0.1), (0.6, 0.5), (0.9, 1.0), (0.6, 0.1), (0.99, 0.05))]
kernels += [("heavy ball", None, lam) for lam in (0.1, 0.5, 1.0)]
worst_id, worst_i, worst_ii, worst_lim = 0.0, 0.0, 0.0, 0.0
for prob in (P1, P2, P3):
    for kind, a, lam in kernels:
        if kind == "Eq. (2)":
            a_w = kernel_eq2(a, lam, K)
            d, D = d_D_eq2(a, lam)
        else:
            q = np.exp(-lam)
            a_w = q ** np.arange(K)
            d, D = 1 / (1 - q), q / (1 - q) ** 2
        T = d - np.concatenate(([0.0], np.cumsum(a_w)))  # T_m = sum_{j >= m} a_j, m = 0..K
        for eta in (1 / (prob["L"] * (d + 2 * D)), 1 / (3 * prob["L"] * (d + 2 * D))):
            TH, G, _ = run_memory(prob, a_w, eta, K)
            th, g = TH[:, 0], G[:, 0]
            # identity of Lemma C1: theta_k - z_k = eta sum_{i<k} T_{k-i} g_i with z_k = theta_0 - eta d sum_{i<k} g_i
            for k in range(1, K + 1):
                z = theta0 - eta * d * g[:k].sum(0)
                lag = eta * (T[k - np.arange(k)][:, None] * g[:k]).sum(0)
                worst_id = max(worst_id, np.linalg.norm(th[k] - z - lag) / (1 + np.linalg.norm(th[k])))
            Ks = np.arange(1, K + 1)
            gn2 = np.cumsum((g ** 2).sum(1))
            delta = prob["f"](theta0) - prob["f_inf"]
            worst_i = max(worst_i, np.max((gn2 / Ks) / (2 * delta / (eta * d * Ks))))
            if prob["convex"]:
                gap = np.cumsum(np.array([prob["f"](t) for t in th[:K]]) - prob["f_inf"])
                R2 = np.sum((theta0 - prob["theta_star"]) ** 2)
                worst_ii = max(worst_ii, np.max((gap / Ks) / (R2 / (eta * d * Ks))))
            worst_lim = max(worst_lim, gn2[-1] * eta * d / (2 * delta))
print(f"Identity of Lemma C1, max relative residual over all runs: {worst_id:.2e}")
print(f"Theorem 4.1 (corrected), part (i): max over runs and K<=300 of LHS / (2 Delta/(eta d K)) = {worst_i:.4f}  (<= 1 required)")
print(f"Theorem 4.1 (corrected), part (ii): max over convex runs and K<=300 of LHS / (R^2/(eta d K)) = {worst_ii:.4f}  (<= 1 required)")
print("  (3 problems x 8 kernels x 2 steps eta = 1/(L(d+2D)) and 1/(3L(d+2D)); kernels: Eq. (2) at 5 (alpha, lambda), heavy ball at 3 lambda)")

# Stochastic: E[xi_k | F_k] = 0, E||xi_k||^2 = sigma^2 (Gaussian), 400 replications
worst_s, worst_sc, n_s, n_sc = 0.0, 0.0, 0, 0
for prob in (P1, P2, P3):
    for kind, a, lam in (("Eq. (2)", 0.6, 0.5), ("Eq. (2)", 0.9, 1.0), ("Eq. (2)", 0.3, 0.1), ("heavy ball", None, 0.5)):
        if kind == "Eq. (2)":
            a_w = kernel_eq2(a, lam, 200)
            d, D = d_D_eq2(a, lam)
        else:
            q = np.exp(-lam)
            a_w = q ** np.arange(200)
            d, D = 1 / (1 - q), q / (1 - q) ** 2
        for sigma in (0.5, 2.0):
            for eta in (1 / (prob["L"] * (d + 2 * D)), 1 / (5 * prob["L"] * (d + 2 * D))):
                TH, G, _ = run_memory(prob, a_w, eta, 200, sigma=sigma, reps=400, seed=7)
                # (i): (1/K) sum_k ||grad f(theta_k)||^2, per replication
                per_rep = (G ** 2).sum(2).mean(0)
                delta = prob["f"](theta0) - prob["f_inf"]
                bound = 2 * delta / (eta * d * 200) + prob["L"] * eta * (d + D) * sigma ** 2
                worst_s = max(worst_s, (per_rep.mean() + 3 * per_rep.std(ddof=1) / np.sqrt(per_rep.size)) / bound)
                n_s += 1
                if prob["convex"]:  # (ii): (1/K) sum_k (f(theta_k) - f*), per replication
                    gap = (prob["f"](TH[:200]) - prob["f_inf"]).mean(0)
                    bound_c = np.sum((theta0 - prob["theta_star"]) ** 2) / (eta * d * 200) + eta * (d + D) * sigma ** 2
                    worst_sc = max(worst_sc, (gap.mean() + 3 * gap.std(ddof=1) / np.sqrt(gap.size)) / bound_c)
                    n_sc += 1
print(f"Theorem 4.2 (corrected), part (i): max over {n_s} settings of (mean + 3 SE) / bound, K = 200, "
      f"400 replications = {worst_s:.4f}  (<= 1 expected)")
print(f"Theorem 4.2 (corrected), part (ii): max over {n_sc} convex settings of (mean + 3 SE) / bound, K = 200, "
      f"400 replications = {worst_sc:.4f}  (<= 1 expected)")
print("  (problems P1-P3 as above, Gaussian noise with E||xi||^2 = sigma^2 in {0.25, 4}, eta = 1/(L(d+2D)) and 1/(5L(d+2D)))")

print("\nDone.")
